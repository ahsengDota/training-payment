export class PaymentDetail {
    PMId : number;
    CardOwnerName : string;
    CardNumber : string;
    Expirationdate : string;
    CVV : string;
}
